
//{{BLOCK(collisionMap)

//======================================================================
//
//	collisionMap, 256x256@16, 
//	+ bitmap not compressed
//	Total size: 131072 = 131072
//
//	Time-stamp: 2017-03-28, 17:30:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_COLLISIONMAP_H
#define GRIT_COLLISIONMAP_H

#define collisionMapBitmapLen 131072
extern const unsigned short collisionMapBitmap[65536];

#endif // GRIT_COLLISIONMAP_H

//}}BLOCK(collisionMap)
