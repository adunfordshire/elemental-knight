enum {PLAYERSPRITE, ENEMYSPRITE};

void drawPlayer(OBJ_ATTR shadowOAM[], PLAYER * player);
void drawEnemy(OBJ_ATTR shadowOAM[], ENEMY enemy[], int numEnemy);
void drawLife(OBJ_ATTR shadowOAM[], LIFE life[]);