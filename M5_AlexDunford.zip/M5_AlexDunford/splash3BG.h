
//{{BLOCK(splash3BG)

//======================================================================
//
//	splash3BG, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 287 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 9184 + 2048 = 11744
//
//	Time-stamp: 2017-04-24, 19:40:49
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPLASH3BG_H
#define GRIT_SPLASH3BG_H

#define splash3BGTilesLen 9184
extern const unsigned short splash3BGTiles[4592];

#define splash3BGMapLen 2048
extern const unsigned short splash3BGMap[1024];

#define splash3BGPalLen 512
extern const unsigned short splash3BGPal[256];

#endif // GRIT_SPLASH3BG_H

//}}BLOCK(splash3BG)
