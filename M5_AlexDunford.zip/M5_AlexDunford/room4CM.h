
//{{BLOCK(room4CM)

//======================================================================
//
//	room4CM, 256x256@16, 
//	+ bitmap not compressed
//	Total size: 131072 = 131072
//
//	Time-stamp: 2017-04-11, 23:25:55
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ROOM4CM_H
#define GRIT_ROOM4CM_H

#define room4CMBitmapLen 131072
extern const unsigned short room4CMBitmap[65536];

#endif // GRIT_ROOM4CM_H

//}}BLOCK(room4CM)
