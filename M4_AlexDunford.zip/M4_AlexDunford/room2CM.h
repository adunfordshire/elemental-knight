
//{{BLOCK(room2CM)

//======================================================================
//
//	room2CM, 256x256@16, 
//	+ bitmap not compressed
//	Total size: 131072 = 131072
//
//	Time-stamp: 2017-04-11, 22:31:32
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ROOM2CM_H
#define GRIT_ROOM2CM_H

#define room2CMBitmapLen 131072
extern const unsigned short room2CMBitmap[65536];

#endif // GRIT_ROOM2CM_H

//}}BLOCK(room2CM)
